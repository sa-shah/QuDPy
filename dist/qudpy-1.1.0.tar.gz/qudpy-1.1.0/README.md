# QuDPy:
## A simple package for nonlinear spectroscopy with quantum dynamics provided by qutip.

### See example_calculations for a detailed example.