# Version of the QuDPy package
__version__ = '1.1.0'
